Before do |scenario|
	Capybara.register_driver :selenium do |app|
  Capybara::Selenium::Driver.new(app, browser: :chrome)
end
  Capybara.default_driver = :selenium_chrome
  Capybara.default_max_wait_time = 20
  page.driver.browser.manage.window.maximize
end

After do |scenario|
  page.execute_script "window.close();"
end