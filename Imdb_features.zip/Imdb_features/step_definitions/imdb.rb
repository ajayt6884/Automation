timestamp = Time.parse(Time.now.to_s)
time = 3600* timestamp.hour + 60 * timestamp.min + timestamp.sec

Given("I am on home page") do                                                                    
  visit "https://www.imdb.com"
end                                                                                              
                                                                                                 
When("I click on the signup button") do                                                          
  find(:xpath, "//*[@id='imdbHeader']/div[2]/div[5]/a/div").click            
end                                                                                              
                                                                                                 
Then("I click on the Create a New Account button") do                                            
  find(:xpath, "//*[@id='signin-options']/div/div[2]/a").click                    
end                                                                                              
                                                                                                 
Then('I entered the valid values in Name, Email, Password and Re-entered password field') do
  fill_in("customerName", :with => "ajay")
  fill_in("email", :with => "ajay.thakur#{time}@vinsol.com")
  fill_in("password", :with => "qwerty@123")
  fill_in("passwordCheck", :with => "qwerty@123")
end                                                                                              
                                                                                                 
Then("click on the create you IMDb account button") do                                           
  find(:xpath, "//*[@id='continue']").click                    
end                                                                                              
                                                                                                 
                                                                                              
Then("I click on the Sign in with IMDb button") do                                               
  find(:xpath, "//*[@id='signin-options']/div/div[1]/a[1]/span[2]").click                    
end                                                                                              
                                                                                                 
Then("I entered the valid values in Email and Password field") do                           
  fill_in("email", :with => "ajayt6884@gmail.com")
  fill_in("password", :with => "12345678")                    
end                                                                                              
                                                                                                 
Then("I click on the signin button") do                                                               
  find(:xpath, "//*[@id='signInSubmit']").click                    
end                                                                                              

When('i click on the menu') do 
  find(:xpath, "//*[@id='imdbHeader']/div[2]/div[5]/a/div").click  
  find(:xpath, "//*[@id='signin-options']/div/div[1]/a[1]/span[2]").click 
  fill_in("email", :with => "ajayt6884@gmail.com")
  fill_in("password", :with => "12345678") 
  find(:xpath, "//*[@id='signInSubmit']").click                                           
  find(:xpath, "//*[@id='imdbHeader-navDrawerOpen--desktop']/div").click
end                                                                          
                                                                             
Then('I click on the Top rated movie button') do                             
  find(:xpath, "//*[@id='imdbHeader']/div[2]/aside/div/div[2]/div/div[1]/span/div/div/ul/a[3]").click
end                                                                          
                                                                             
Then('I select the Release Date option from sort by dropdown') do            
  find(:xpath, "//*[@id='lister-sort-by-options']/option[3]").click
end                                                                          
                                                                             
Then('I go to the last movie of the list') do
  page.execute_script "window.scrollBy(0,-10000)"                                
  find(:xpath, "//*[@id='main']/div/span/div/div/div[3]/table/tbody/tr[250]/td[2]/a").click
end                                                                          
                                                                             
Then('I click on the release date of the movie') do                          
  find(:xpath, "//*[@id='title-overview-widget']/div[1]/div[2]/div/div[2]/div[2]/div/a[4]").click
end                                                                                                                                                    